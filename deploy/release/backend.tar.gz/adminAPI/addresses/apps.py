from django.apps import AppConfig


class AddressesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'addresses'
    verbose_name = '收货地址'
