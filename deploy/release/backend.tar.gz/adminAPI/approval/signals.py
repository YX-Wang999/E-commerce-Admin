"""Approval app signals placeholder."""
