"""Points application."""

from django.apps import AppConfig


class PointsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'points'
    verbose_name = '积分管理'

    def ready(self) -> None:
        """Register signal handlers."""
        import points.signals  # noqa: F401
